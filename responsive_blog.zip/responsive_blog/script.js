document.getElementById('dark-mode-toggle').addEventListener('click', function() {
    document.body.classList.toggle('dark-mode');
});

document.querySelectorAll('.read-more-btn').forEach(function(button) {
    button.addEventListener('click', function() {
        var fullContent = this.previousElementSibling;
        fullContent.classList.toggle('hidden');
        this.textContent = fullContent.classList.contains('hidden') ? 'Read More' : 'Read Less';
    });
});

document.getElementById('comment-form').addEventListener('submit', function(e) {
    e.preventDefault();
    var commentInput = document.getElementById('comment-input');
    var commentText = commentInput.value;
    if (commentText) {
        var comment = document.createElement('div');
        comment.className = 'comment';
        comment.textContent = commentText;
        document.getElementById('comments-container').appendChild(comment);
        commentInput.value = '';
    }
});

document.getElementById('clear-comments').addEventListener('click', function() {
    document.getElementById('comments-container').innerHTML = '';
});

// Remove inline styling for read more buttons
document.querySelectorAll('.read-more-btn').forEach(function(button) {
    button.style.backgroundColor = 'inherit';
    button.style.color = 'inherit';
    button.style.border = 'none';
    button.style.padding = '0';
    button.style.cursor = 'pointer';
});

document.querySelectorAll('.read-more-btn:hover').forEach(function(button) {
    button.style.backgroundColor = 'inherit';
});
