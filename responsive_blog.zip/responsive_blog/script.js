document.addEventListener('DOMContentLoaded', function () {
    var darkModeToggle = document.getElementById('dark-mode-toggle');
    var body = document.body;
    var readMoreButtons = document.querySelectorAll('.read-more-btn');
    var commentForm = document.getElementById('comment-form');
    var commentInput = document.getElementById('comment-input');
    var commentsContainer = document.getElementById('comments-container');
    var clearCommentsButton = document.getElementById('clear-comments');

    darkModeToggle.addEventListener('click', function () {
        body.classList.toggle('dark-mode');
    });

    readMoreButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            var shortContent = this.previousElementSibling.previousElementSibling;
            var fullContent = this.previousElementSibling;

            shortContent.classList.toggle('hidden');
            fullContent.classList.toggle('hidden');
            this.textContent = fullContent.classList.contains('hidden') ? 'Read More' : 'Read Less';
        });
    });

    function loadComments() {
        commentsContainer.innerHTML = '';
        var comments = JSON.parse(localStorage.getItem('comments')) || [];
        comments.forEach(function (comment) {
            var commentElement = document.createElement('div');
            commentElement.classList.add('comment');
            commentElement.textContent = comment;
            commentsContainer.appendChild(commentElement);
        });
    }

    loadComments();

    commentForm.addEventListener('submit', function (event) {
        event.preventDefault();
        var comment = commentInput.value;
        if (comment) {
            var comments = JSON.parse(localStorage.getItem('comments')) || [];
            comments.push(comment);
            localStorage.setItem('comments', JSON.stringify(comments));
            commentInput.value = '';
            loadComments();
        }
    });

    clearCommentsButton.addEventListener('click', function () {
        localStorage.removeItem('comments');
        loadComments();
    });
});
